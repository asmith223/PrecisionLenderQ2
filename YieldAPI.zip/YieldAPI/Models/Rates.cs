using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace YieldAPI
{
    public class Rate
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public string Term { get; set; }

        public double  TermRate { get; set; }

    }

    public class RateDbContext : DbContext
    {
        public DbSet<Rate> Rates { get; set; }

        public RateDbContext(DbContextOptions<RateDbContext> options) : base(options)
        {
            LoadGetRates();
        }

        public List<Rate> GetRates() => Rates.Local.ToList();

        private void LoadGetRates()
        {
            Rates.Add(new Rate { Id = 1, Name = "Libor 1 Month", Term = "1", TermRate = 0.004969 });
            Rates.Add(new Rate { Id = 2, Name = "Libor 2 Month", Term = "2", TermRate = 0.006105 });
            Rates.Add(new Rate { Id = 3, Name = "Libor 3 Month", Term = "3", TermRate = 0.007776 });
            Rates.Add(new Rate { Id = 4, Name = "Libor 6 Month", Term = "6", TermRate = 0.011442 });
            Rates.Add(new Rate { Id = 5, Name = "Libor 12 Month", Term = "12", TermRate = 0.014546 });
        }
    }
}
